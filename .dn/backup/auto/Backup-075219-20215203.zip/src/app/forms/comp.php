<?php
namespace app\forms;

use std, gui, framework, app;


class comp extends AbstractForm
{

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        
    }

}
