<?php
namespace app\forms;

use std, gui, framework, app;


class dekstop extends AbstractForm
{

    /**
     * @event labelAlt.keyPress 
     */
    function doLabelAltKeyPress(UXKeyEvent $e = null)
    {    
        
    }

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event buttonAlt.click-Left 
     */
    function doButtonAltClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button3.click-Left 
     */
    function doButton3ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button4.click-Left 
     */
    function doButton4ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        
    }

    /**
     * @event rect.click-Left 
     */
    function doRectClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect4.click-Left 
     */
    function doRect4ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label8.click-Left 
     */
    function doLabel8ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label17.click-Left 
     */
    function doLabel17ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label16.click-Left 
     */
    function doLabel16ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label15.click-Left 
     */
    function doLabel15ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

}
