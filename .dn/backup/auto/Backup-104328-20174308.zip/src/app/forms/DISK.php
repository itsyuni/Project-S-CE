<?php
namespace app\forms;

use std, gui, framework, app;


class DISK extends AbstractForm
{

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

}
